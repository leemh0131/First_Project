package com.myproject.utils;

public class search {
	
	//검색어를 받아온다
	private String keyword;
	
	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	

}
