package com.myproject.domain;


import lombok.Data;

@Data
public class TestBean {
	
	private MemberVO member;
	private LikeyVO likey;
	private BasketVO basket;
	private orderVO orders;
	private productVO products;

}
